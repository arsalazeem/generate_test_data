from setuptools import setup

setup(name='generate_test_data',
      version='1.0',
      description='Package To Generate Test Data for Testing/QA',
      author='Arsal Azeem',
      author_email='gward@python.net',
      url='https://www.python.org/sigs/distutils-sig/',
      # packages=['distutils', 'distutils.command'],

     )